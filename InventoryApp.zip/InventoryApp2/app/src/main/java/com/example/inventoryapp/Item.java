package com.example.inventoryapp;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "items_table")
public class Item {

    @PrimaryKey(autoGenerate = true)
    private int mId;
    @ColumnInfo(name = "name")
    private String mName;
    @ColumnInfo(name = "price")
    private Integer mPrice;
    @ColumnInfo(name = "quantity")
    private Integer mQuantity;
    @ColumnInfo(name = "supplier")
    private String mSupplier;

    public Item(String name, int price, int quantity, String supplier) {
        this.mName = name;
        this.mPrice = price;
        this.mQuantity = quantity;
        this.mSupplier = supplier;
    }

    public int getId() {
        return mId;
    }

    public void setId(int id) {
        this.mId = id;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        this.mName = name;
    }

    public Integer getPrice() {
        return mPrice;
    }

    public Integer getQuantity() {
        return mQuantity;
    }

    public String getSupplier() {
        return mSupplier;
    }
}
